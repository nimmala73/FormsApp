﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;
using WPFProject.Forms;

namespace WPFProject
{
    /// <summary>
    /// Interaction logic for MainScreen.xaml
    /// </summary>
    public partial class MainScreen : UserControl
    {
        ObservableCollection<ListViewData> list;

        public MainScreen()
        {
            InitializeComponent();
            list = new ObservableCollection<ListViewData>();
            LoadListViewData();
            showColumnChart();
        }

        private void showColumnChart()
        {
            List<KeyValuePair<string, int>> MyValue = new List<KeyValuePair<string, int>>();
            MyValue.Add(new KeyValuePair<string, int>("Mahak", 300));
            MyValue.Add(new KeyValuePair<string, int>("Pihu", 250));
            MyValue.Add(new KeyValuePair<string, int>("Rahul", 289));
            MyValue.Add(new KeyValuePair<string, int>("Raj", 256));
            MyValue.Add(new KeyValuePair<string, int>("Vikas", 140));

            
            ColumnChart1.DataContext = MyValue;

        }

        private void LoadListViewData()
        {
            for (int i = 1; i <= 13; i++)
            {
                ListViewData data = new ListViewData();
                var tuple = AssaignData(i);
                data.Name = tuple.Item1;
                data.Image = tuple.Item2;
                data.Type = i;
                list.Add(data);
            }
            listView.ItemsSource = list;
        }

        private Tuple<string, Image> AssaignData(int type)
        {
            switch(type)
            {
               case 1 : return new Tuple<string, Image>("Selection", (Image)TryFindResource("ImgSelectionG"));
               case 2: return new Tuple<string, Image>("Order", (Image)TryFindResource("ImgOrderG"));
               case 3: return new Tuple<string, Image>("Status", (Image)TryFindResource("ImgStatusG"));
               case 4: return new Tuple<string, Image>("Batches", (Image)TryFindResource("ImgBatchesG"));
               case 5: return new Tuple<string, Image>("Sample", (Image)TryFindResource("ImgSampleG"));
               case 6: return new Tuple<string, Image>("Criteria", (Image)TryFindResource("ImgCriteriaG"));
               case 7: return new Tuple<string, Image>("WorkList", (Image)TryFindResource("ImgWorkListG"));
               case 8: return new Tuple<string, Image>("History", (Image)TryFindResource("ImgHistoryG"));
               case 9: return new Tuple<string, Image>("New Order", (Image)TryFindResource("ImgNewOrderG"));
               case 10: return new Tuple<string, Image>("Refresh", (Image)TryFindResource("ImgRefreshG"));
               case 11: return new Tuple<string, Image>("Barcode", (Image)TryFindResource("ImgBarcodeG"));
               case 12: return new Tuple<string, Image>("Logout", (Image)TryFindResource("ImgLogoutG"));
               case 13: return new Tuple<string, Image>("Exit", (Image)TryFindResource("ImgExitG"));
                default: return new Tuple<string, Image>("",new Image());
            }
        }

        bool isMenuClicked = false;
        private void BtnMenu_Click(object sender, RoutedEventArgs e)
        {
            if (!isMenuClicked)
            {
                mainGrid.ColumnDefinitions[0].Width = new GridLength(70);
                list.Select(x => { x.IsVisible = Visibility.Collapsed; return x; }).ToList();
                tbprofile.Visibility = Visibility.Collapsed;
                isMenuClicked = true;
            }
            else
            {
                mainGrid.ColumnDefinitions[0].Width = new GridLength(220);
                list.Select(x => { x.IsVisible = Visibility.Visible; return x; }).ToList();
                tbprofile.Visibility = Visibility.Visible;
                isMenuClicked = false;
            }
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listView.SelectedItem != null)
            {
                ListViewData data = listView.SelectedItem as ListViewData;
                if (data != null)
                {
                    contentGrid.Children.Clear();
                    if (data.Type == 12 || data.Type == 13)
                    {
                        Window window = Window.GetWindow(this);
                        window.Close();
                        return;
                    }
                    else if (data.Type == 1 || data.Type == 8)
                    {
                        contentGrid.Children.Add(new UCHistory());
                    }
                    else
                        contentGrid.Children.Add(new UCCenterForm());
                    data.Image = ChangeImageOnSelection(data.Type);
                }
                if (e.RemovedItems.Count > 0)
                {
                    ListViewData unSelectedItem = e.RemovedItems[0] as ListViewData;
                    if (unSelectedItem != null)
                        unSelectedItem.Image = ChangeImageOnUnSelection(unSelectedItem.Type);
                }              
            }
        }

        private Image ChangeImageOnSelection(int type)
        {
            switch (type)
            {
                case 1: return (Image)TryFindResource("ImgSelection");
                case 2: return (Image)TryFindResource("ImgOrder");
                case 3: return (Image)TryFindResource("ImgStatus");
                case 4: return (Image)TryFindResource("ImgBatches");
                case 5: return (Image)TryFindResource("ImgSample");
                case 6: return (Image)TryFindResource("ImgCriteria");
                case 7: return (Image)TryFindResource("ImgWorkList");
                case 8: return (Image)TryFindResource("ImgHistory");
                case 9: return (Image)TryFindResource("ImgNewOrder");
                case 10: return (Image)TryFindResource("ImgRefresh");
                case 11: return (Image)TryFindResource("ImgBarcode");
                case 12: return (Image)TryFindResource("ImgLogout");
                case 13: return (Image)TryFindResource("ImgExit");
                default: return new Image();
            }
        }

        private Image ChangeImageOnUnSelection(int type)
        {
            switch (type)
            {
                case 1: return (Image)TryFindResource("ImgSelectionG");
                case 2: return (Image)TryFindResource("ImgOrderG");
                case 3: return (Image)TryFindResource("ImgStatusG");
                case 4: return (Image)TryFindResource("ImgBatchesG");
                case 5: return (Image)TryFindResource("ImgSampleG");
                case 6: return (Image)TryFindResource("ImgCriteriaG");
                case 7: return (Image)TryFindResource("ImgWorkListG");
                case 8: return (Image)TryFindResource("ImgHistoryG");
                case 9: return (Image)TryFindResource("ImgNewOrderG");
                case 10: return (Image)TryFindResource("ImgRefreshG");
                case 11: return (Image)TryFindResource("ImgBarcodeG");
                case 12: return (Image)TryFindResource("ImgLogoutG");
                case 13: return (Image)TryFindResource("ImgExitG");
                default: return new Image();
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Window window = Window.GetWindow(this);
            window.Close();
        }
    }

    public class ListViewData : INotifyPropertyChanged
    {
        Image image = new Image();
        Visibility isVisible = Visibility.Visible;
        public int Type;
        ObservableCollection<ListViewData> childData = new ObservableCollection<ListViewData>();
        Visibility childVisible = Visibility.Collapsed;

        public Image Image
        {
            get
            {
                return image;
            }
            set
            {
                image = value;
                OnPropertyChanged("Image");
            }
        }

        public string Name { get; set; }

        public Visibility IsVisible
        {
            get
            {
                return isVisible;
            }
            set
            {
                isVisible = value;
                OnPropertyChanged("IsVisible");
            }
        }
        public ObservableCollection<ListViewData> ChildData
        {
            get
            {
                return childData;
            }
            set
            {
                childData = value;
                OnPropertyChanged("ChildData");
            }
        }
        public Visibility ChildVisible
        {
            get
            {
                return childVisible;
            }
            set
            {
                childVisible = value;
                OnPropertyChanged("ChildVisible");
            }
        }

        public ListViewData()
        {

        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
