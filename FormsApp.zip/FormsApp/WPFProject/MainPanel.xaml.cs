﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFProject.Forms;
using System.ComponentModel;

namespace WPFProject
{
    /// <summary>
    /// Interaction logic for MainPanel.xaml
    /// </summary>
    public partial class MainPanel : UserControl
    {
        DummyClass _class;
        public MainPanel()
        {
            InitializeComponent();
            _class = new DummyClass();
            this.DataContext = _class;
            //_class.IsVisible = Visibility.Collapsed;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sp2.IsVisible)
                sp2.Visibility = Visibility.Collapsed;
            else
                sp2.Visibility = Visibility.Visible;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            childGird.Children.Clear();
            childGird.Children.Add(new UC1());
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            childGird.Children.Clear();
            childGird.Children.Add(new UC2());
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            childGird.Children.Clear();
            childGird.Children.Add(new UC3());
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            _class.IsVisible = Visibility.Collapsed;
        }
    }

    public class DummyClass :INotifyPropertyChanged
    {
        Visibility isVisible = Visibility.Visible;

        public Visibility IsVisible
        {
            get
            {
                return isVisible;
            }
            set
            {
                isVisible = value;
                OnPropertyChanged("IsVisible");
            }
        }

        public DummyClass()
        {
                
        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null && !string.IsNullOrEmpty(propertyName))
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
