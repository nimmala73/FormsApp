﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFProject.Forms;

namespace WPFProject
{
    /// <summary>
    /// Interaction logic for MainScreen1.xaml
    /// </summary>
    public partial class MainScreen1 : UserControl
    {
        ObservableCollection<ListViewData> list;

        public MainScreen1()
        {
            InitializeComponent();
            list = new ObservableCollection<ListViewData>();
            LoadListViewData();
        }

        private void LoadListViewData()
        {
            for (int i = 1; i <= 5; i++)
            {
                ListViewData data = new ListViewData();
                var tuple = AssaignMainData(i);
                data.Name = tuple.Item1;
                data.Image = tuple.Item2;
                //data.Type = i;
                if (i == 2)
                {                    
                    for (int j = 1; j <= 9; j++)
                    {
                        ListViewData childData = new ListViewData();
                        var tuple1 = AssaignchildData(j);
                        childData.Name = tuple1.Item1;
                        childData.Image = tuple1.Item2;
                        childData.Type = j;
                        data.ChildData.Add(childData);
                    }
                }
                //if (data.ChildData.Count > 0)
                //    data.ChildVisible = Visibility.Visible;
                list.Add(data);
            }
            listView.ItemsSource = list;
        }

        private Tuple<string, Image> AssaignMainData(int type)
        {
            switch (type)
            {
                case 1: return new Tuple<string, Image>("File", (Image)TryFindResource("ImgFileG"));
                case 2: return new Tuple<string, Image>("Modules", (Image)TryFindResource("ImgModulesG"));
                case 3: return new Tuple<string, Image>("Display", (Image)TryFindResource("ImgDisplayG"));
                case 4: return new Tuple<string, Image>("User", (Image)TryFindResource("ImgUserG"));
                case 5: return new Tuple<string, Image>("Help", (Image)TryFindResource("ImgHelpG"));
                default: return new Tuple<string, Image>("", new Image());
            }
        }

        private Tuple<string, Image> AssaignchildData(int type)
        {
            switch (type)
            {
                case 1: return new Tuple<string, Image>("Selection", (Image)TryFindResource("ImgSelectionG"));
                case 2: return new Tuple<string, Image>("Order", (Image)TryFindResource("ImgOrderG"));
                case 3: return new Tuple<string, Image>("Status", (Image)TryFindResource("ImgStatusG"));
                case 4: return new Tuple<string, Image>("Batches", (Image)TryFindResource("ImgBatchesG"));
                case 5: return new Tuple<string, Image>("Sample", (Image)TryFindResource("ImgSampleG"));
                case 6: return new Tuple<string, Image>("Criteria", (Image)TryFindResource("ImgCriteriaG"));
                case 7: return new Tuple<string, Image>("WorkList", (Image)TryFindResource("ImgWorkListG"));
                case 8: return new Tuple<string, Image>("History", (Image)TryFindResource("ImgHistoryG"));
                case 9: return new Tuple<string, Image>("New Order", (Image)TryFindResource("ImgNewOrderG"));
                default: return new Tuple<string, Image>("", new Image());
            }
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listView.SelectedItem != null)
            {
                ListViewData data = listView.SelectedItem as ListViewData;
                if (data != null)
                {
                    if (data.ChildData.Count > 0)
                        data.ChildVisible = Visibility.Visible;
                    contentGrid.Children.Clear();
                    if (data.Type == 12 || data.Type == 13)
                    {
                        Window window = Window.GetWindow(this);
                        window.Close();
                        return;
                    }
                    else if (data.Type == 1 || data.Type == 8)
                    {
                        contentGrid.Children.Add(new UCHistory());
                    }
                    else
                        contentGrid.Children.Add(new UCCenterForm());
                    //data.Image = ChangeImageOnSelection(data.Type);
                }
                if (e.RemovedItems.Count > 0)
                {
                    ListViewData unSelectedItem = e.RemovedItems[0] as ListViewData;
                    if (unSelectedItem != null)
                    {
                        unSelectedItem.ChildVisible = Visibility.Collapsed;
                        //unSelectedItem.Image = ChangeImageOnUnSelection(unSelectedItem.Type);
                    }
                }
            }
        }

        private Image ChangeImageOnSelection(int type)
        {
            switch (type)
            {
                case 1: return (Image)TryFindResource("ImgSelection");
                case 2: return (Image)TryFindResource("ImgOrder");
                case 3: return (Image)TryFindResource("ImgStatus");
                case 4: return (Image)TryFindResource("ImgBatches");
                case 5: return (Image)TryFindResource("ImgSample");
                case 6: return (Image)TryFindResource("ImgCriteria");
                case 7: return (Image)TryFindResource("ImgWorkList");
                case 8: return (Image)TryFindResource("ImgHistory");
                case 9: return (Image)TryFindResource("ImgNewOrder");
                case 10: return (Image)TryFindResource("ImgRefresh");
                case 11: return (Image)TryFindResource("ImgBarcode");
                case 12: return (Image)TryFindResource("ImgLogout");
                case 13: return (Image)TryFindResource("ImgExit");
                default: return new Image();
            }
        }

        private Image ChangeImageOnUnSelection(int type)
        {
            switch (type)
            {
                case 1: return (Image)TryFindResource("ImgSelectionG");
                case 2: return (Image)TryFindResource("ImgOrderG");
                case 3: return (Image)TryFindResource("ImgStatusG");
                case 4: return (Image)TryFindResource("ImgBatchesG");
                case 5: return (Image)TryFindResource("ImgSampleG");
                case 6: return (Image)TryFindResource("ImgCriteriaG");
                case 7: return (Image)TryFindResource("ImgWorkListG");
                case 8: return (Image)TryFindResource("ImgHistoryG");
                case 9: return (Image)TryFindResource("ImgNewOrderG");
                case 10: return (Image)TryFindResource("ImgRefreshG");
                case 11: return (Image)TryFindResource("ImgBarcodeG");
                case 12: return (Image)TryFindResource("ImgLogoutG");
                case 13: return (Image)TryFindResource("ImgExitG");
                default: return new Image();
            }
        }

        bool isMenuClicked = false;
        private void BtnMenu_Click(object sender, RoutedEventArgs e)
        {
            if (!isMenuClicked)
            {
                mainGrid.ColumnDefinitions[0].Width = new GridLength(90);
                list.Select(x => { x.IsVisible = Visibility.Collapsed; return x; }).ToList();
                tbprofile.Visibility = Visibility.Collapsed;
                isMenuClicked = true;
            }
            else
            {
                mainGrid.ColumnDefinitions[0].Width = new GridLength(220);
                list.Select(x => { x.IsVisible = Visibility.Visible; return x; }).ToList();
                tbprofile.Visibility = Visibility.Visible;
                isMenuClicked = false;
            }
        }
    }
}
