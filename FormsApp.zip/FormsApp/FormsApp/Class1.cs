﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormsApp
{
    public class Class1
    {
        public Class1()
        {
            try
            {
                ClassA[] arrayA = new ClassA[3];
                for (int i = 0; i < arrayA.Length; i++)
                {
                    ClassA b = new ClassA();
                    b.Id = i;
                    arrayA[i] = b;
                }

                var output = (from b in arrayA
                              where b.Id == 2
                              select b).ToArray();
            }
            catch(Exception)
            { }
        }
    }

    public class ClassA
    {
        int id = 0;
        ClassB[] arrayB = new ClassB[5];

        public ClassA()
        {
            for (int i = 0; i < arrayB.Length; i++)
            {
                ClassB b = new ClassB();
                b.Id = i;
                arrayB[i] = b;
            }
        }

        public int Id { get => id; set => id = value; }
        public ClassB[] ArrayB { get => arrayB; set => arrayB = value; }
    }

    public class ClassB
    {
        int id = 0;
        ClassC[] arrayC = new ClassC[4];
        
        public ClassB()
        {
            for (int i = 0; i < arrayC.Length; i++)
            {
                ClassC c = new ClassC();
                c.Id = i;
                c.Name = "C" + i;
                ArrayC[i] = c;
            }
        }

        public ClassC[] ArrayC { get => arrayC; set => arrayC = value; }
        public int Id { get => id; set => id = value; }
    }

    public class ClassC
    {
        int id = 0;
        string name = string.Empty;
        public ClassC()
        {

        }

        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
    }
}
